<template>
  <div>
    <p>Hello from route with query: {{ $route.query }}</p>
  </div>
</template>

<script>
export default {
}
</script>
