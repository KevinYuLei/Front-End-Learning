<template>
  <div class="parent">
    <h2>Parent</h2>
    <router-view class="child" />
  </div>
</template>

<script>
export default {

}
</script>
