export function installToast () {
  // @TODO
}
