<template>
  <div class="w-full h-full flex items-center justify-center">
    <VueIcon
      icon="code_off"
      class="w-20 h-20 text-gray-400 dark:text-gray-600"
    />
  </div>
</template>
